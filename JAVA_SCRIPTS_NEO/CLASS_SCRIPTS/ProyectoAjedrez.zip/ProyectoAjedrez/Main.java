package JAVA_SCRIPTS_NEO.CLASS_SCRIPTS.ProyectoAjedrez;
public class Main {
    public static void main(String[] args) {
        // Crear las piezas utilizando polimorfismo
        Pieza alfilBlanco = new Alfil("C1", "Blanco", 1);
        Pieza reyBlanco = new Rey("E1", "Blanco", 1);
        Pieza torreNegra = new Torre("A8", "Negro", -1);
        Pieza reyNegro = new Rey("E8", "Negro", -1);

        // Crear el tablero de 8x8 e inicializar sus elementos en "___"
        String[][] tablero = new String[8][8];
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                tablero[i][j] = "___";
            }
        }

        // Obtener la posición de cada pieza y ubicarla en el tablero
        ubicarPiezaEnTablero(tablero, alfilBlanco);
        ubicarPiezaEnTablero(tablero, reyBlanco);
        ubicarPiezaEnTablero(tablero, torreNegra);
        ubicarPiezaEnTablero(tablero, reyNegro);

        // Imprimir el tablero
        imprimirTablero(tablero);
    }

    public static void ubicarPiezaEnTablero(String[][] tablero, Pieza pieza) {
        int fila = pieza.getFila();
        int columna = pieza.getColumna();
        tablero[fila][columna] = pieza.obtenerPosicion();
    }

    public static void imprimirTablero(String[][] tablero) {
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                System.out.print(tablero[i][j] + " ");
            }
            System.out.println();
        }
    }
}
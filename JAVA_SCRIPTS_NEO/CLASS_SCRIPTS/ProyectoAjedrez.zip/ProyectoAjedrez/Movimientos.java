package JAVA_SCRIPTS_NEO.CLASS_SCRIPTS.ProyectoAjedrez;
import java.util.*;

public interface Movimientos {
    void mostrarPosiblesMovimientos(ArrayList<Pieza> piezas);
    boolean jaque(ArrayList<Pieza> piezas);
}


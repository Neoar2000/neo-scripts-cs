package JAVA_SCRIPTS_NEO.CLASS_SCRIPTS.ProyectoAjedrez;
import java.util.*;

public class Rey extends Pieza implements Movimientos {
    public Rey(String posicion, String color, int direccion) {
        super(posicion, color, direccion);
        this.nombre = "Rey";
    }

    @Override
    public String obtenerPosicion() {
        return this.nombre + (char) (this.columna + 97) + (8 - this.fila);
    }

    @Override
    public void mostrarPosiblesMovimientos(ArrayList<Pieza> piezas) {
        // Lógica para calcular los posibles movimientos del Rey
        System.out.println("Mostrando posibles movimientos del Rey.");
    }

    @Override
    public boolean jaque(ArrayList<Pieza> piezas) {
        // Lógica para verificar si el Rey pone en jaque al Rey del color opuesto
        return false;
    }
}
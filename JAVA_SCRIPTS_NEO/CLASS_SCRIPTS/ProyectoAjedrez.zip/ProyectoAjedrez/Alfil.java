package JAVA_SCRIPTS_NEO.CLASS_SCRIPTS.ProyectoAjedrez;
import java.util.*;

public class Alfil extends Pieza implements Movimientos {
    public Alfil(String posicion, String color, int direccion) {
        super(posicion, color, direccion);
        this.nombre = "Alfil";
    }

    @Override
    public String obtenerPosicion() {
        return this.nombre + (char) (this.columna + 97) + (8 - this.fila);
    }

    @Override
    public void mostrarPosiblesMovimientos(ArrayList<Pieza> piezas) {
        // Lógica para calcular los posibles movimientos del Alfil
        System.out.println("Mostrando posibles movimientos del Alfil.");
    }

    @Override
    public boolean jaque(ArrayList<Pieza> piezas) {
        // Lógica para verificar si el Alfil pone en jaque al Rey del color opuesto
        return false;
    }
}
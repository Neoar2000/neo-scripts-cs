package JAVA_SCRIPTS_NEO.CLASS_SCRIPTS.ProyectoAjedrez;
import java.util.*;

public class Dama extends Pieza implements Movimientos {
    public Dama(String posicion, String color, int direccion) {
        super(posicion, color, direccion);
        this.nombre = "Dama";
    }

    @Override
    public String obtenerPosicion() {
        return this.nombre + (char) (this.columna + 97) + (8 - this.fila);
    }

    @Override
    public void mostrarPosiblesMovimientos(ArrayList<Pieza> piezas) {
        // Lógica para calcular los posibles movimientos de la Dama
        System.out.println("Mostrando posibles movimientos de la Dama.");
    }

    @Override
    public boolean jaque(ArrayList<Pieza> piezas) {
        // Lógica para verificar si la Dama pone en jaque al Rey del color opuesto
        return false;
    }
}
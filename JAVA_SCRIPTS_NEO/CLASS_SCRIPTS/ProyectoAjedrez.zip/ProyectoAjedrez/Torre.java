package JAVA_SCRIPTS_NEO.CLASS_SCRIPTS.ProyectoAjedrez;
import java.util.*;

public class Torre extends Pieza implements Movimientos {
    public Torre(String posicion, String color, int direccion) {
        super(posicion, color, direccion);
        this.nombre = "Torre";
    }

    @Override
    public String obtenerPosicion() {
        return this.nombre + (char) (this.columna + 97) + (8 - this.fila);
    }

    @Override
    public void mostrarPosiblesMovimientos(ArrayList<Pieza> piezas) {
        // Lógica para calcular los posibles movimientos de la Torre
        System.out.println("Mostrando posibles movimientos de la Torre.");
    }

    @Override
    public boolean jaque(ArrayList<Pieza> piezas) {
        // Lógica para verificar si la Torre pone en jaque al Rey del color opuesto
        return false;
    }
}
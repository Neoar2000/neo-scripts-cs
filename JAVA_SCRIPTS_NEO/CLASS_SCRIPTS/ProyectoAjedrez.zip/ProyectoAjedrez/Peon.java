package JAVA_SCRIPTS_NEO.CLASS_SCRIPTS.ProyectoAjedrez;
import java.util.*;

public class Peon extends Pieza implements Movimientos {
    public Peon(String posicion, String color, int direccion) {
        super(posicion, color, direccion);
        this.nombre = "Peon";
    }

    @Override
    public String obtenerPosicion() {
        return this.nombre + (char) (this.columna + 97) + (8 - this.fila);
    }

    @Override
    public void mostrarPosiblesMovimientos(ArrayList<Pieza> piezas) {
        // Lógica para calcular los posibles movimientos del Peón
        System.out.println("Mostrando posibles movimientos del Peón.");
    }

    @Override
    public boolean jaque(ArrayList<Pieza> piezas) {
        // Lógica para verificar si el Peón pone en jaque al Rey del color opuesto
        return false;
    }
}

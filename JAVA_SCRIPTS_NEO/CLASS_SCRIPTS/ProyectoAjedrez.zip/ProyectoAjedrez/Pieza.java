package JAVA_SCRIPTS_NEO.CLASS_SCRIPTS.ProyectoAjedrez;
public abstract class Pieza {
    protected String nombre;
    protected String color;
    protected int fila;
    protected int columna;
    protected int direccion;
    protected boolean estado;

    public Pieza(String posicion, String color, int direccion) {
        this.nombre = obtenerNombre(posicion);
        this.color = color;
        this.direccion = direccion;
        this.estado = true;
        this.fila = obtenerFila(posicion);
        this.columna = obtenerColumna(posicion);
    }

    public String getNombre() {
        return nombre;
    }

    public String getColor() {
        return color;
    }

    public int getFila() {
        return fila;
    }

    public int getColumna() {
        return columna;
    }

    public void cambiarPosicion(String posicion) {
        this.fila = obtenerFila(posicion);
        this.columna = obtenerColumna(posicion);
    }

    public abstract String obtenerPosicion();

    private String obtenerNombre(String posicion) {
        return posicion.substring(0, 1);
    }

    private int obtenerFila(String posicion) {
        return 8 - Integer.parseInt(posicion.substring(2, 3));
    }

    private int obtenerColumna(String posicion) {
        return (int) (posicion.charAt(1)) - 97;
    }
}
